<?php $__env->startSection('content'); ?>
    <div class="container justify-content-center">

        <div style=" display: flex;
  align-items: center;
  justify-content: center;">
            <img src="<?php echo e(asset('img/avatar.svg')); ?>" style="width: 200px ; margin: 0 auto">

        </div>




        <h1 align="center" style="margin-top: 10px">Profile</h1>

        <h3>Nama : <?php echo e(Auth::user()->id); ?></h3>
        <h3>Email : <?php echo e(Auth::user()->email); ?></h3>
        <h3>No. Handphone : <?php echo e(Auth::user()->no_hp); ?></h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Voting\resources\views/profile.blade.php ENDPATH**/ ?>