<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container justify-content-center" style="margin-top: 10px">
        <h1 align="center">Vote Kandidat</h1>

        <div style="display: flex;margin-top: 70px;justify-content: center">
            <div class="card border-primary" style="width: 18rem ; margin-right: 50px">
                <img src="<?php echo e(asset('img/avatar.svg')); ?>" style="width: 65%;margin: 0 auto ; margin-top: 50px" class="card-img-top" alt="...">
                <hr>
                <div class="card-body">
                    <p class="card-text"> No urut : 1</p>
                    <p class="card-text"> Visi : xxx</p>
                    <p class="card-text"> Misi : xxx</p>


                </div>
                <div class="card-footer">
                    <?php if(count($test) == 0): ?>
                    <a href="votes/1/<?php echo e(Auth::user()->id); ?>" class="btn btn-success" style="width: 100%">Vote</a>
                    <?php else: ?>
                        <p>Anda sudah melakukan Voting</p>
                    <?php endif; ?>
                </div>
            </div>



            <div class="card border-primary" style="width: 18rem">
                <img src="<?php echo e(asset('img/avatar.svg')); ?>" style="width: 65%;margin: 0 auto ; margin-top: 50px" class="card-img-top" alt="...">
                <hr>
                <div class="card-body">
                    <p class="card-text"> No urut : 2</p>
                    <p class="card-text"> Visi : xxx</p>
                    <p class="card-text"> Misi : xxx</p>


                </div>
                <div class="card-footer">
                    <?php if(count($test) == 0): ?>
                        <a href="votes/2/<?php echo e(Auth::user()->id); ?>" class="btn btn-success" style="width: 100%">Vote</a>
                    <?php else: ?>
                        <p>Anda sudah melakukan Voting</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>


    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#0099ff" fill-opacity="1" d="M0,160L30,160C60,160,120,160,180,138.7C240,117,300,75,360,74.7C420,75,480,117,540,138.7C600,160,660,160,720,144C780,128,840,96,900,74.7C960,53,1020,43,1080,42.7C1140,43,1200,53,1260,58.7C1320,64,1380,64,1410,64L1440,64L1440,320L1410,320C1380,320,1320,320,1260,320C1200,320,1140,320,1080,320C1020,320,960,320,900,320C840,320,780,320,720,320C660,320,600,320,540,320C480,320,420,320,360,320C300,320,240,320,180,320C120,320,60,320,30,320L0,320Z"></path></svg>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\E-Voting\resources\views/vote.blade.php ENDPATH**/ ?>